const SHEETS = {
  DASHBOARD: "Dashboard",
  MOVEMENTS: "Movimientos",
  INVOICES: "Facturas",
  CLIENTS: "Clientes",
  PROVIDERS: "Proveedores",
  CATEGORIES: "Categorias",
  CONFIG: "Configuracion",
};

const HEADER_ROW = 5;
const START_ROW = 6;

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("Sistema Contable")
    .addItem("Abrir panel", "showPanel")
    .addItem("Verificar estructura", "ensureSetup")
    .addToUi();
}

function doGet() {
  return HtmlService.createTemplateFromFile("Index")
    .evaluate()
    .setTitle("Sistema Contable")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function showPanel() {
  const html = HtmlService.createTemplateFromFile("Index")
    .evaluate()
    .setTitle("Sistema Contable")
    .setWidth(1200)
    .setHeight(780);
  SpreadsheetApp.getUi().showModalDialog(html, "Sistema Contable");
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function ensureSetup() {
  const ss = SpreadsheetApp.getActive();
  Object.keys(SHEETS).forEach((key) => {
    if (!ss.getSheetByName(SHEETS[key])) {
      ss.insertSheet(SHEETS[key]);
    }
  });
  return { ok: true, message: "Estructura verificada" };
}

function getDashboardData() {
  const dashboard = getSheet_(SHEETS.DASHBOARD);
  const movementSheet = getSheet_(SHEETS.MOVEMENTS);
  const invoiceSheet = getSheet_(SHEETS.INVOICES);

  const kpiLabels = dashboard.getRange("A4:D4").getDisplayValues()[0];
  const kpiValues = dashboard.getRange("A5:D5").getDisplayValues()[0];
  const secondLabels = dashboard.getRange("F4:H4").getDisplayValues()[0];
  const secondValues = dashboard.getRange("F5:H5").getDisplayValues()[0];
  const alerts = dashboard.getRange("F10:H13").getDisplayValues()
    .filter((row) => row[0]);
  const monthly = dashboard.getRange("A10:D21").getDisplayValues()
    .filter((row) => row[0]);

  return {
    ok: true,
    updatedAt: Utilities.formatDate(new Date(), timezone_(), "yyyy-MM-dd HH:mm"),
    kpis: [
      { label: kpiLabels[0], value: kpiValues[0], tone: "good" },
      { label: kpiLabels[1], value: kpiValues[1], tone: "bad" },
      { label: kpiLabels[2], value: kpiValues[2], tone: "good" },
      { label: kpiLabels[3], value: kpiValues[3], tone: "neutral" },
      { label: secondLabels[0], value: secondValues[0], tone: "warn" },
      { label: secondLabels[1], value: secondValues[1], tone: Number(secondValues[1]) > 0 ? "bad" : "good" },
      { label: secondLabels[2], value: secondValues[2], tone: "neutral" },
    ],
    alerts: alerts.map((row) => ({ label: row[0], value: row[1], status: row[2] })),
    monthly: monthly.map((row) => ({
      month: row[0],
      income: row[1],
      expense: row[2],
      profit: row[3],
    })),
    movementCount: countDataRows_(movementSheet),
    invoiceCount: countDataRows_(invoiceSheet),
  };
}

function getCatalogs() {
  const categorySheet = getSheet_(SHEETS.CATEGORIES);
  const configSheet = getSheet_(SHEETS.CONFIG);
  const categories = readColumn_(categorySheet, 6, 2)
    .filter(Boolean);
  const accounts = readColumn_(configSheet, 6, 4)
    .filter(Boolean);
  const paymentMethods = readColumn_(configSheet, 16, 4)
    .filter(Boolean);
  const clients = readNames_(SHEETS.CLIENTS);
  const providers = readNames_(SHEETS.PROVIDERS);

  return {
    ok: true,
    categories,
    accounts,
    paymentMethods,
    clients,
    providers,
    types: ["Ingreso", "Gasto"],
    invoiceTypes: ["Cliente", "Proveedor"],
  };
}

function addMovement(payload) {
  ensureSetup();
  const sheet = getSheet_(SHEETS.MOVEMENTS);
  const row = nextEmptyRow_(sheet, 1);
  const date = parseDate_(payload.fecha);
  const type = String(payload.tipo || "").trim();
  const amount = Math.abs(toNumber_(payload.monto));
  const income = type === "Ingreso" ? amount : 0;
  const expense = type === "Gasto" ? amount : 0;

  if (!date || !type || !amount) {
    throw new Error("Fecha, tipo y monto son obligatorios.");
  }

  sheet.getRange(row, 1, 1, 10).setValues([[
    date,
    type,
    payload.cuenta || "",
    payload.categoria || "",
    payload.descripcion || "",
    payload.tercero || "",
    payload.metodo || "",
    payload.referencia || "",
    income,
    expense,
  ]]);
  sheet.getRange(row, 11, 1, 3).setFormulas([[
    `=IF(AND(I${row}="",J${row}=""),"",SUM($I$6:I${row})-SUM($J$6:J${row}))`,
    `=IF(A${row}="","",TEXT(A${row},"yyyy-mm"))`,
    `=IF(A${row}="","","MOV-"&TEXT(ROW()-5,"0000"))`,
  ]]);

  return {
    ok: true,
    message: "Movimiento registrado",
    row,
    dashboard: getDashboardData(),
  };
}

function addInvoice(payload) {
  ensureSetup();
  const sheet = getSheet_(SHEETS.INVOICES);
  const row = nextEmptyRow_(sheet, 1);
  const date = parseDate_(payload.fecha);
  const dueDate = parseDate_(payload.vencimiento);
  const total = Math.abs(toNumber_(payload.total));
  const paid = Math.abs(toNumber_(payload.pagado));

  if (!date || !payload.tipo || !payload.nombre || !total) {
    throw new Error("Fecha, tipo, nombre y total son obligatorios.");
  }

  sheet.getRange(row, 1, 1, 6).setValues([[
    date,
    payload.tipo || "",
    payload.nombre || "",
    payload.descripcion || "",
    total,
    paid,
  ]]);
  sheet.getRange(row, 7).setFormula(`=IF(E${row}="","",E${row}-F${row})`);
  sheet.getRange(row, 8).setValue(dueDate || "");
  sheet.getRange(row, 9).setFormula(`=IF(A${row}="","",IF(G${row}<=0,"Pagada",IF(H${row}<TODAY(),"Vencida","Pendiente")))`);
  sheet.getRange(row, 10).setValue(payload.referencia || "");
  sheet.getRange(row, 11).setFormula(`=IF(A${row}="","","FAC-"&TEXT(ROW()-5,"0000"))`);

  return {
    ok: true,
    message: "Factura registrada",
    row,
    dashboard: getDashboardData(),
  };
}

function getMovements(limit) {
  const sheet = getSheet_(SHEETS.MOVEMENTS);
  const last = Math.max(sheet.getLastRow(), START_ROW);
  const rows = sheet.getRange(START_ROW, 1, last - START_ROW + 1, 13).getDisplayValues()
    .filter((row) => row[0])
    .map((row) => ({
      fecha: row[0],
      tipo: row[1],
      cuenta: row[2],
      categoria: row[3],
      descripcion: row[4],
      tercero: row[5],
      metodo: row[6],
      referencia: row[7],
      ingreso: row[8],
      gasto: row[9],
      saldo: row[10],
      mes: row[11],
      id: row[12],
    }));
  const max = Number(limit || 50);
  return { ok: true, rows: rows.slice(-max).reverse() };
}

function getInvoices(limit) {
  const sheet = getSheet_(SHEETS.INVOICES);
  const last = Math.max(sheet.getLastRow(), START_ROW);
  const rows = sheet.getRange(START_ROW, 1, last - START_ROW + 1, 11).getDisplayValues()
    .filter((row) => row[0])
    .map((row) => ({
      fecha: row[0],
      tipo: row[1],
      nombre: row[2],
      descripcion: row[3],
      total: row[4],
      pagado: row[5],
      pendiente: row[6],
      vencimiento: row[7],
      estado: row[8],
      referencia: row[9],
      id: row[10],
    }));
  const max = Number(limit || 50);
  return { ok: true, rows: rows.slice(-max).reverse() };
}

function getMonthlyReport() {
  const dashboard = getSheet_(SHEETS.DASHBOARD);
  const rows = dashboard.getRange("A10:D21").getDisplayValues()
    .filter((row) => row[0]);
  return {
    ok: true,
    rows: rows.map((row) => ({
      mes: row[0],
      ingresos: row[1],
      gastos: row[2],
      utilidad: row[3],
    })),
  };
}

function getSheet_(name) {
  const sheet = SpreadsheetApp.getActive().getSheetByName(name);
  if (!sheet) {
    throw new Error(`No existe la hoja: ${name}`);
  }
  return sheet;
}

function nextEmptyRow_(sheet, keyColumn) {
  const maxRows = sheet.getMaxRows();
  const values = sheet.getRange(START_ROW, keyColumn, maxRows - START_ROW + 1, 1).getValues();
  for (let index = 0; index < values.length; index += 1) {
    if (!values[index][0]) {
      return START_ROW + index;
    }
  }
  return sheet.getLastRow() + 1;
}

function countDataRows_(sheet) {
  const last = Math.max(sheet.getLastRow(), START_ROW);
  return sheet.getRange(START_ROW, 1, last - START_ROW + 1, 1)
    .getDisplayValues()
    .filter((row) => row[0])
    .length;
}

function readColumn_(sheet, startRow, column) {
  const last = Math.max(sheet.getLastRow(), startRow);
  return sheet.getRange(startRow, column, last - startRow + 1, 1)
    .getDisplayValues()
    .map((row) => String(row[0]).trim())
    .filter(Boolean);
}

function readNames_(sheetName) {
  const sheet = getSheet_(sheetName);
  const last = Math.max(sheet.getLastRow(), START_ROW);
  return sheet.getRange(START_ROW, 2, last - START_ROW + 1, 1)
    .getDisplayValues()
    .map((row) => String(row[0]).trim())
    .filter(Boolean);
}

function parseDate_(value) {
  if (!value) return null;
  if (Object.prototype.toString.call(value) === "[object Date]") return value;
  const parts = String(value).split("-");
  if (parts.length === 3) {
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function toNumber_(value) {
  if (typeof value === "number") return value;
  return Number(String(value || "0").replace(/[^\d.-]/g, "")) || 0;
}

function timezone_() {
  return Session.getScriptTimeZone() || "America/Bogota";
}
