const TARGET_SPREADSHEET_ID = "10hEGcnQb4IcGjc_voCu4ktnaJdUheHWbVfP5imwUZP0";

const SHEETS = {
  DASHBOARD: "Dashboard",
  MOVEMENTS: "Movimientos",
  INVOICES: "Facturas",
  CLIENTS: "Clientes",
  PROVIDERS: "Proveedores",
  CATEGORIES: "Categorias",
  CONFIG: "Configuracion",
};

const HEADER_ROW = 5;
const START_ROW = 6;
const MAX_MOVEMENTS = 200;
const MAX_INVOICES = 100;
const MAX_DIRECTORY = 100;

const COLORS = {
  ink: "#172033",
  muted: "#667085",
  primary: "#0F766E",
  primaryDark: "#115E59",
  softTeal: "#DDF7F2",
  softBlue: "#EAF2FF",
  softAmber: "#FFF4D6",
  softRed: "#FEE2E2",
  white: "#FFFFFF",
  border: "#D8DEE9",
  header: "#EEF2F7",
};

const CATEGORIES = [
  ["Ingreso", "Ventas", "Ventas de productos o servicios"],
  ["Ingreso", "Servicios", "Servicios prestados"],
  ["Ingreso", "Otros ingresos", "Ingresos no recurrentes"],
  ["Gasto", "Compras", "Compra de mercancia o insumos"],
  ["Gasto", "Arriendo", "Pago de local, oficina o bodega"],
  ["Gasto", "Servicios publicos", "Agua, luz, internet y telefonia"],
  ["Gasto", "Nomina", "Pagos de personal"],
  ["Gasto", "Transporte", "Domicilios, gasolina o transporte"],
  ["Gasto", "Marketing", "Publicidad y promocion"],
  ["Gasto", "Impuestos", "Impuestos y tasas"],
  ["Gasto", "Otros gastos", "Gastos varios"],
];

const ACCOUNTS = ["Caja", "Banco", "Nequi", "Daviplata", "Tarjeta"];
const PAYMENT_METHODS = ["Efectivo", "Transferencia", "Tarjeta", "Nequi", "Daviplata", "Credito"];

const SAMPLE_MOVEMENTS = [
  ["2026-06-01", "Ingreso", "Banco", "Ventas", "Venta contado", "Cliente general", "Transferencia", "REC-001", 1250000, 0],
  ["2026-06-02", "Gasto", "Banco", "Compras", "Compra de inventario", "Proveedor Norte", "Transferencia", "FAC-P001", 0, 420000],
  ["2026-06-03", "Ingreso", "Caja", "Servicios", "Servicio tecnico", "Laura Perez", "Efectivo", "REC-002", 360000, 0],
  ["2026-06-04", "Gasto", "Nequi", "Transporte", "Domicilios", "Mensajeria rapida", "Nequi", "GAS-001", 0, 65000],
  ["2026-06-05", "Gasto", "Banco", "Servicios publicos", "Internet del negocio", "Operador local", "Transferencia", "GAS-002", 0, 98000],
  ["2026-06-06", "Ingreso", "Daviplata", "Ventas", "Venta por redes", "Carlos Ruiz", "Daviplata", "REC-003", 540000, 0],
  ["2026-06-07", "Gasto", "Banco", "Marketing", "Pauta digital", "Meta Ads", "Tarjeta", "GAS-003", 0, 120000],
  ["2026-06-08", "Ingreso", "Banco", "Otros ingresos", "Abono extraordinario", "Cliente general", "Transferencia", "REC-004", 180000, 0],
];

const SAMPLE_INVOICES = [
  ["2026-06-01", "Cliente", "Laura Perez", "Servicio tecnico mensual", 650000, 300000, "2026-06-12", "FAC-C001"],
  ["2026-06-02", "Cliente", "Carlos Ruiz", "Pedido por redes", 540000, 540000, "2026-06-10", "FAC-C002"],
  ["2026-06-03", "Proveedor", "Proveedor Norte", "Mercancia de junio", 920000, 420000, "2026-06-18", "FAC-P001"],
  ["2026-05-20", "Proveedor", "Operador local", "Internet negocio", 98000, 0, "2026-06-03", "FAC-P002"],
];

const SAMPLE_CLIENTS = [
  ["CLI-001", "Cliente general", "", "", "", "Cliente contado"],
  ["CLI-002", "Laura Perez", "3200000001", "laura@example.com", "Bogota", "Servicio recurrente"],
  ["CLI-003", "Carlos Ruiz", "3200000002", "carlos@example.com", "Medellin", "Compra por redes"],
];

const SAMPLE_PROVIDERS = [
  ["PRO-001", "Proveedor Norte", "3100000001", "ventas@proveedornorte.com", "Bogota", "Mercancia"],
  ["PRO-002", "Operador local", "3100000002", "soporte@operador.com", "Bogota", "Internet"],
  ["PRO-003", "Mensajeria rapida", "3100000003", "", "Bogota", "Domicilios"],
];

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("Sistema Contable")
    .addItem("Abrir panel", "showPanel")
    .addItem("Crear/actualizar estructura", "setupSistemaContable")
    .addItem("Verificar estructura", "ensureSetup")
    .addToUi();
}

function doGet() {
  return HtmlService.createTemplateFromFile("Index")
    .evaluate()
    .setTitle("Sistema Contable")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function showPanel() {
  const html = HtmlService.createTemplateFromFile("Index")
    .evaluate()
    .setTitle("Sistema Contable")
    .setWidth(1200)
    .setHeight(780);
  SpreadsheetApp.getUi().showModalDialog(html, "Sistema Contable");
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function setTargetSpreadsheetId(id) {
  PropertiesService.getScriptProperties().setProperty("TARGET_SPREADSHEET_ID", id);
  return { ok: true, message: `Hoja objetivo configurada: ${id}` };
}

function createNativeSistemaContable() {
  const ss = SpreadsheetApp.create("Sistema Contable");
  PropertiesService.getScriptProperties().setProperty("TARGET_SPREADSHEET_ID", ss.getId());
  buildWorkbook_(ss);
  return {
    ok: true,
    id: ss.getId(),
    url: ss.getUrl(),
    message: "Hoja nativa creada. Guarda este enlace y despliega el panel como Web App si usas script independiente.",
  };
}

function setupSistemaContable() {
  const ss = getWorkbook_();
  buildWorkbook_(ss);
  return { ok: true, message: "Sistema Contable creado/actualizado", url: ss.getUrl() };
}

function ensureSetup() {
  const ss = getWorkbook_();
  const missing = Object.keys(SHEETS).some((key) => !ss.getSheetByName(SHEETS[key]));
  if (missing) {
    buildWorkbook_(ss);
    return { ok: true, message: "Estructura creada" };
  }
  return { ok: true, message: "Estructura verificada" };
}

function getDashboardData() {
  ensureSetup();
  const dashboard = getSheet_(SHEETS.DASHBOARD);
  const movementSheet = getSheet_(SHEETS.MOVEMENTS);
  const invoiceSheet = getSheet_(SHEETS.INVOICES);

  const kpiLabels = dashboard.getRange("A4:D4").getDisplayValues()[0];
  const kpiValues = dashboard.getRange("A5:D5").getDisplayValues()[0];
  const secondLabels = dashboard.getRange("F4:H4").getDisplayValues()[0];
  const secondValues = dashboard.getRange("F5:H5").getDisplayValues()[0];
  const alerts = dashboard.getRange("F10:H13").getDisplayValues().filter((row) => row[0]);
  const monthly = dashboard.getRange("A10:D21").getDisplayValues().filter((row) => row[0]);

  return {
    ok: true,
    updatedAt: Utilities.formatDate(new Date(), timezone_(), "yyyy-MM-dd HH:mm"),
    kpis: [
      { label: kpiLabels[0], value: kpiValues[0], tone: "good" },
      { label: kpiLabels[1], value: kpiValues[1], tone: "bad" },
      { label: kpiLabels[2], value: kpiValues[2], tone: "good" },
      { label: kpiLabels[3], value: kpiValues[3], tone: "neutral" },
      { label: secondLabels[0], value: secondValues[0], tone: "warn" },
      { label: secondLabels[1], value: secondValues[1], tone: Number(secondValues[1]) > 0 ? "bad" : "good" },
      { label: secondLabels[2], value: secondValues[2], tone: "neutral" },
    ],
    alerts: alerts.map((row) => ({ label: row[0], value: row[1], status: row[2] })),
    monthly: monthly.map((row) => ({
      month: row[0],
      income: row[1],
      expense: row[2],
      profit: row[3],
    })),
    movementCount: countDataRows_(movementSheet),
    invoiceCount: countDataRows_(invoiceSheet),
  };
}

function getCatalogs() {
  ensureSetup();
  const categorySheet = getSheet_(SHEETS.CATEGORIES);
  const configSheet = getSheet_(SHEETS.CONFIG);
  const categories = readColumn_(categorySheet, 6, 2).filter(Boolean);
  const accounts = readColumn_(configSheet, 6, 4).filter(Boolean);
  const paymentMethods = readColumn_(configSheet, 16, 4).filter(Boolean);
  const clients = readNames_(SHEETS.CLIENTS);
  const providers = readNames_(SHEETS.PROVIDERS);

  return {
    ok: true,
    categories,
    accounts,
    paymentMethods,
    clients,
    providers,
    types: ["Ingreso", "Gasto"],
    invoiceTypes: ["Cliente", "Proveedor"],
  };
}

function addMovement(payload) {
  ensureSetup();
  const sheet = getSheet_(SHEETS.MOVEMENTS);
  const row = nextEmptyRow_(sheet, 1);
  const date = parseDate_(payload.fecha);
  const type = String(payload.tipo || "").trim();
  const amount = Math.abs(toNumber_(payload.monto));
  const income = type === "Ingreso" ? amount : 0;
  const expense = type === "Gasto" ? amount : 0;

  if (!date || !type || !amount) {
    throw new Error("Fecha, tipo y monto son obligatorios.");
  }

  sheet.getRange(row, 1, 1, 10).setValues([[
    date,
    type,
    payload.cuenta || "",
    payload.categoria || "",
    payload.descripcion || "",
    payload.tercero || "",
    payload.metodo || "",
    payload.referencia || "",
    income,
    expense,
  ]]);
  sheet.getRange(row, 11, 1, 3).setFormulas([[
    `=IF(AND(I${row}="",J${row}=""),"",SUM($I$6:I${row})-SUM($J$6:J${row}))`,
    `=IF(A${row}="","",TEXT(A${row},"yyyy-mm"))`,
    `=IF(A${row}="","","MOV-"&TEXT(ROW()-5,"0000"))`,
  ]]);

  return { ok: true, message: "Movimiento registrado", row, dashboard: getDashboardData() };
}

function addInvoice(payload) {
  ensureSetup();
  const sheet = getSheet_(SHEETS.INVOICES);
  const row = nextEmptyRow_(sheet, 1);
  const date = parseDate_(payload.fecha);
  const dueDate = parseDate_(payload.vencimiento);
  const total = Math.abs(toNumber_(payload.total));
  const paid = Math.abs(toNumber_(payload.pagado));

  if (!date || !payload.tipo || !payload.nombre || !total) {
    throw new Error("Fecha, tipo, nombre y total son obligatorios.");
  }

  sheet.getRange(row, 1, 1, 6).setValues([[
    date,
    payload.tipo || "",
    payload.nombre || "",
    payload.descripcion || "",
    total,
    paid,
  ]]);
  sheet.getRange(row, 7).setFormula(`=IF(E${row}="","",E${row}-F${row})`);
  sheet.getRange(row, 8).setValue(dueDate || "");
  sheet.getRange(row, 9).setFormula(`=IF(A${row}="","",IF(G${row}<=0,"Pagada",IF(H${row}<TODAY(),"Vencida","Pendiente")))`);
  sheet.getRange(row, 10).setValue(payload.referencia || "");
  sheet.getRange(row, 11).setFormula(`=IF(A${row}="","","FAC-"&TEXT(ROW()-5,"0000"))`);

  return { ok: true, message: "Factura registrada", row, dashboard: getDashboardData() };
}

function getMovements(limit) {
  ensureSetup();
  const sheet = getSheet_(SHEETS.MOVEMENTS);
  const last = Math.max(sheet.getLastRow(), START_ROW);
  const rows = sheet.getRange(START_ROW, 1, last - START_ROW + 1, 13).getDisplayValues()
    .filter((row) => row[0])
    .map((row) => ({
      fecha: row[0],
      tipo: row[1],
      cuenta: row[2],
      categoria: row[3],
      descripcion: row[4],
      tercero: row[5],
      metodo: row[6],
      referencia: row[7],
      ingreso: row[8],
      gasto: row[9],
      saldo: row[10],
      mes: row[11],
      id: row[12],
    }));
  const max = Number(limit || 50);
  return { ok: true, rows: rows.slice(-max).reverse() };
}

function getInvoices(limit) {
  ensureSetup();
  const sheet = getSheet_(SHEETS.INVOICES);
  const last = Math.max(sheet.getLastRow(), START_ROW);
  const rows = sheet.getRange(START_ROW, 1, last - START_ROW + 1, 11).getDisplayValues()
    .filter((row) => row[0])
    .map((row) => ({
      fecha: row[0],
      tipo: row[1],
      nombre: row[2],
      descripcion: row[3],
      total: row[4],
      pagado: row[5],
      pendiente: row[6],
      vencimiento: row[7],
      estado: row[8],
      referencia: row[9],
      id: row[10],
    }));
  const max = Number(limit || 50);
  return { ok: true, rows: rows.slice(-max).reverse() };
}

function getMonthlyReport() {
  ensureSetup();
  const dashboard = getSheet_(SHEETS.DASHBOARD);
  const rows = dashboard.getRange("A10:D21").getDisplayValues().filter((row) => row[0]);
  return {
    ok: true,
    rows: rows.map((row) => ({
      mes: row[0],
      ingresos: row[1],
      gastos: row[2],
      utilidad: row[3],
    })),
  };
}

function buildWorkbook_(ss) {
  removeDefaultSheets_(ss);
  const sheets = {};
  Object.keys(SHEETS).forEach((key) => {
    sheets[key] = ss.getSheetByName(SHEETS[key]) || ss.insertSheet(SHEETS[key]);
    sheets[key].clear();
    sheets[key].setHiddenGridlines(true);
  });

  setupDashboard_(sheets.DASHBOARD);
  setupMovements_(sheets.MOVEMENTS);
  setupInvoices_(sheets.INVOICES);
  setupDirectory_(sheets.CLIENTS, "Clientes", SAMPLE_CLIENTS, "Cliente");
  setupDirectory_(sheets.PROVIDERS, "Proveedores", SAMPLE_PROVIDERS, "Proveedor");
  setupCategories_(sheets.CATEGORIES);
  setupConfig_(sheets.CONFIG);

  addCharts_(sheets.DASHBOARD);
  ss.setActiveSheet(sheets.DASHBOARD);
}

function removeDefaultSheets_(ss) {
  const keepNames = Object.keys(SHEETS).map((key) => SHEETS[key]);
  ss.getSheets().forEach((sheet) => {
    if (!keepNames.includes(sheet.getName()) && ss.getSheets().length > 1) {
      ss.deleteSheet(sheet);
    }
  });
}

function setupDashboard_(sheet) {
  title_(sheet, "A1:H1", "Sistema Contable", "A2:H2", "Panel principal - valores en COP");
  setWidths_(sheet, [130, 125, 125, 125, 30, 145, 145, 145, 145, 145, 145, 145, 145]);
  sheet.setFrozenRows(2);

  sheet.getRange("A4:D5").setValues([
    ["Ingresos", "Gastos", "Utilidad", "Saldo"],
    ["=SUM(Movimientos!I6:I205)", "=SUM(Movimientos!J6:J205)", "=A5-B5", "=C5"],
  ]);
  header_(sheet.getRange("A4:D4"), COLORS.softTeal);
  body_(sheet.getRange("A5:D5")).setFontWeight("bold").setFontSize(14).setHorizontalAlignment("center");
  sheet.getRange("A5:D5").setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');

  sheet.getRange("F4:H5").setValues([
    ["Facturas pendientes", "Facturas vencidas", "Clientes"],
    ["=SUM(Facturas!G6:G105)", '=COUNTIF(Facturas!I6:I105,"Vencida")', "=COUNTA(Clientes!B6:B105)"],
  ]);
  header_(sheet.getRange("F4:H4"), COLORS.softAmber);
  body_(sheet.getRange("F5:H5")).setFontWeight("bold").setFontSize(14).setHorizontalAlignment("center");
  sheet.getRange("F5").setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');

  section_(sheet, "A8:D8", "Resumen mensual", COLORS.softBlue);
  sheet.getRange("A9:D9").setValues([["Mes", "Ingresos", "Gastos", "Utilidad"]]);
  header_(sheet.getRange("A9:D9"), COLORS.header);
  const months = [];
  for (let i = 1; i <= 12; i += 1) {
    const row = 9 + i;
    const month = `2026-${String(i).padStart(2, "0")}`;
    months.push([month, `=SUMIF(Movimientos!L6:L205,A${row},Movimientos!I6:I205)`, `=SUMIF(Movimientos!L6:L205,A${row},Movimientos!J6:J205)`, `=B${row}-C${row}`]);
  }
  sheet.getRange("A10:D21").setValues(months);
  body_(sheet.getRange("A10:D21"));
  sheet.getRange("B10:D21").setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');

  section_(sheet, "A24:D24", "Resumen por categoria", COLORS.softBlue);
  sheet.getRange("A25:D25").setValues([["Categoria", "Ingresos", "Gastos", "Neto"]]);
  header_(sheet.getRange("A25:D25"), COLORS.header);
  const catRows = CATEGORIES.map((item, index) => {
    const row = 26 + index;
    return [item[1], `=SUMIF(Movimientos!D6:D205,A${row},Movimientos!I6:I205)`, `=SUMIF(Movimientos!D6:D205,A${row},Movimientos!J6:J205)`, `=B${row}-C${row}`];
  });
  sheet.getRange(26, 1, catRows.length, 4).setValues(catRows);
  body_(sheet.getRange(26, 1, catRows.length, 4));
  sheet.getRange(26, 2, catRows.length, 3).setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');

  section_(sheet, "F8:H8", "Alertas", COLORS.softAmber);
  sheet.getRange("F9:H13").setValues([
    ["Alerta", "Valor", "Estado"],
    ["Facturas vencidas", "=G5", '=IF(G5>0,"Revisar","OK")'],
    ["Utilidad del mes", '=SUMIF(A10:A21,TEXT(TODAY(),"yyyy-mm"),D10:D21)', '=IF(G10<0,"Perdida","OK")'],
    ["Gasto del mes", '=SUMIF(A10:A21,TEXT(TODAY(),"yyyy-mm"),C10:C21)', '=IF(G11>SUMIF(A10:A21,TEXT(TODAY(),"yyyy-mm"),B10:B21)*0.75,"Alto","OK")'],
    ["Saldo disponible", "=D5", '=IF(G12<0,"Negativo","OK")'],
  ]);
  header_(sheet.getRange("F9:H9"), COLORS.header);
  body_(sheet.getRange("F10:H13"));
  sheet.getRange("G11:G13").setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');
}

function setupMovements_(sheet) {
  title_(sheet, "A1:M1", "Movimientos", "A2:M2", "Registro diario de ingresos y gastos");
  setWidths_(sheet, [105, 100, 100, 135, 220, 140, 120, 120, 115, 115, 115, 95, 95]);
  sheet.setFrozenRows(5);
  sheet.getRange("A5:M5").setValues([["Fecha", "Tipo", "Cuenta", "Categoria", "Descripcion", "Tercero", "Metodo de pago", "Referencia", "Ingreso", "Gasto", "Saldo", "Mes", "ID"]]);
  darkHeader_(sheet.getRange("A5:M5"));

  const rows = [];
  for (let i = 0; i < MAX_MOVEMENTS; i += 1) {
    const row = START_ROW + i;
    const sample = SAMPLE_MOVEMENTS[i];
    if (sample) {
      rows.push([parseDate_(sample[0]), ...sample.slice(1), `=IF(AND(I${row}="",J${row}=""),"",SUM($I$6:I${row})-SUM($J$6:J${row}))`, `=IF(A${row}="","",TEXT(A${row},"yyyy-mm"))`, `=IF(A${row}="","","MOV-"&TEXT(ROW()-5,"0000"))`]);
    } else {
      rows.push(["", "", "", "", "", "", "", "", "", "", `=IF(AND(I${row}="",J${row}=""),"",SUM($I$6:I${row})-SUM($J$6:J${row}))`, `=IF(A${row}="","",TEXT(A${row},"yyyy-mm"))`, `=IF(A${row}="","","MOV-"&TEXT(ROW()-5,"0000"))`]);
    }
  }
  sheet.getRange(START_ROW, 1, MAX_MOVEMENTS, 13).setValues(rows);
  body_(sheet.getRange(START_ROW, 1, MAX_MOVEMENTS, 13));
  sheet.getRange("A6:A205").setNumberFormat("yyyy-mm-dd");
  sheet.getRange("I6:K205").setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');
  validation_(sheet.getRange("B6:B205"), ["Ingreso", "Gasto"]);
  validation_(sheet.getRange("C6:C205"), ACCOUNTS);
  validation_(sheet.getRange("D6:D205"), CATEGORIES.map((item) => item[1]));
  validation_(sheet.getRange("G6:G205"), PAYMENT_METHODS);
  sheet.getRange("A5:M205").createFilter();
}

function setupInvoices_(sheet) {
  title_(sheet, "A1:K1", "Facturas", "A2:K2", "Control de cuentas por cobrar y por pagar");
  setWidths_(sheet, [105, 105, 160, 220, 115, 115, 115, 120, 105, 120, 95]);
  sheet.setFrozenRows(5);
  sheet.getRange("A5:K5").setValues([["Fecha", "Tipo", "Nombre", "Descripcion", "Total", "Pagado", "Pendiente", "Vencimiento", "Estado", "Referencia", "ID"]]);
  darkHeader_(sheet.getRange("A5:K5"));
  const rows = [];
  for (let i = 0; i < MAX_INVOICES; i += 1) {
    const row = START_ROW + i;
    const sample = SAMPLE_INVOICES[i];
    if (sample) {
      rows.push([parseDate_(sample[0]), sample[1], sample[2], sample[3], sample[4], sample[5], `=IF(E${row}="","",E${row}-F${row})`, parseDate_(sample[6]), `=IF(G${row}<=0,"Pagada",IF(H${row}<TODAY(),"Vencida","Pendiente"))`, sample[7], `=IF(A${row}="","","FAC-"&TEXT(ROW()-5,"0000"))`]);
    } else {
      rows.push(["", "", "", "", "", "", `=IF(E${row}="","",E${row}-F${row})`, "", `=IF(A${row}="","",IF(G${row}<=0,"Pagada",IF(H${row}<TODAY(),"Vencida","Pendiente")))`, "", `=IF(A${row}="","","FAC-"&TEXT(ROW()-5,"0000"))`]);
    }
  }
  sheet.getRange(START_ROW, 1, MAX_INVOICES, 11).setValues(rows);
  body_(sheet.getRange(START_ROW, 1, MAX_INVOICES, 11));
  sheet.getRange("A6:A105").setNumberFormat("yyyy-mm-dd");
  sheet.getRange("H6:H105").setNumberFormat("yyyy-mm-dd");
  sheet.getRange("E6:G105").setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');
  validation_(sheet.getRange("B6:B105"), ["Cliente", "Proveedor"]);
  validation_(sheet.getRange("I6:I105"), ["Pendiente", "Pagada", "Vencida"]);
  sheet.getRange("A5:K105").createFilter();
}

function setupDirectory_(sheet, title, sampleRows, type) {
  title_(sheet, "A1:G1", title, "A2:G2", type === "Cliente" ? "Directorio y saldo pendiente" : "Directorio y cuentas por pagar");
  setWidths_(sheet, [95, 170, 120, 200, 170, 220, 130]);
  sheet.setFrozenRows(5);
  sheet.getRange("A5:G5").setValues([["ID", "Nombre", "Telefono", "Email", "Direccion", "Notas", "Pendiente"]]);
  darkHeader_(sheet.getRange("A5:G5"));
  const rows = [];
  for (let i = 0; i < MAX_DIRECTORY; i += 1) {
    const row = START_ROW + i;
    const sample = sampleRows[i] || ["", "", "", "", "", ""];
    rows.push([...sample, `=IF(B${row}="","",SUMIFS(Facturas!G$6:G$105,Facturas!B$6:B$105,"${type}",Facturas!C$6:C$105,B${row}))`]);
  }
  sheet.getRange(START_ROW, 1, MAX_DIRECTORY, 7).setValues(rows);
  body_(sheet.getRange(START_ROW, 1, MAX_DIRECTORY, 7));
  sheet.getRange("G6:G105").setNumberFormat('"COP" #,##0;[Red]-"COP" #,##0;-');
  sheet.getRange("A5:G105").createFilter();
}

function setupCategories_(sheet) {
  title_(sheet, "A1:C1", "Categorias", "A2:C2", "Catalogo editable para clasificar movimientos");
  setWidths_(sheet, [110, 160, 310]);
  sheet.setFrozenRows(5);
  sheet.getRange("A5:C5").setValues([["Tipo", "Categoria", "Descripcion"]]);
  darkHeader_(sheet.getRange("A5:C5"));
  sheet.getRange(START_ROW, 1, CATEGORIES.length, 3).setValues(CATEGORIES);
  body_(sheet.getRange(START_ROW, 1, CATEGORIES.length, 3));
  validation_(sheet.getRange(START_ROW, 1, CATEGORIES.length, 1), ["Ingreso", "Gasto"]);
  sheet.getRange(HEADER_ROW, 1, CATEGORIES.length + 1, 3).createFilter();
}

function setupConfig_(sheet) {
  title_(sheet, "A1:F1", "Configuracion", "A2:F2", "Ajustes del sistema");
  setWidths_(sheet, [150, 210, 40, 150, 170, 220]);
  section_(sheet, "A4:B4", "Datos del negocio", COLORS.softTeal);
  sheet.getRange("A5:B10").setValues([
    ["Nombre del negocio", "Mi negocio"],
    ["Moneda", "COP"],
    ["Periodo actual", '=TEXT(TODAY(),"yyyy-mm")'],
    ["Creado", new Date()],
    ["Version", "1.1 Google Sheets nativo"],
    ["Estado", "Listo"],
  ]);
  body_(sheet.getRange("A5:B10"));
  sheet.getRange("B8").setNumberFormat("yyyy-mm-dd");

  section_(sheet, "D4:E4", "Cuentas", COLORS.softBlue);
  sheet.getRange("D5:E5").setValues([["Cuenta", "Uso"]]);
  header_(sheet.getRange("D5:E5"), COLORS.header);
  sheet.getRange(6, 4, ACCOUNTS.length, 2).setValues(ACCOUNTS.map((item) => [item, "Disponible"]));
  body_(sheet.getRange(6, 4, ACCOUNTS.length, 2));

  section_(sheet, "D14:E14", "Metodos de pago", COLORS.softBlue);
  sheet.getRange("D15:E15").setValues([["Metodo", "Uso"]]);
  header_(sheet.getRange("D15:E15"), COLORS.header);
  sheet.getRange(16, 4, PAYMENT_METHODS.length, 2).setValues(PAYMENT_METHODS.map((item) => [item, "Disponible"]));
  body_(sheet.getRange(16, 4, PAYMENT_METHODS.length, 2));

  section_(sheet, "A13:B13", "Uso rapido", COLORS.softAmber);
  sheet.getRange("A14:B19").setValues([
    ["1", "Registra ingresos y gastos en Movimientos o desde el panel HTML."],
    ["2", "Usa Facturas para controlar cobros y pagos pendientes."],
    ["3", "Edita Categorias, Cuentas y Metodos segun tu negocio."],
    ["4", "El Dashboard se actualiza con formulas."],
    ["5", "No contiene IA ni claves externas."],
    ["6", "Si el archivo venia de Excel, usa una hoja Google Sheets nativa."],
  ]);
  body_(sheet.getRange("A14:B19"));
  sheet.getRange("B14:B19").setWrap(true);
}

function addCharts_(sheet) {
  sheet.getCharts().forEach((chart) => sheet.removeChart(chart));
  const monthlyChart = sheet.newChart()
    .asColumnChart()
    .addRange(sheet.getRange("A9:D21"))
    .setOption("title", "Ingresos, gastos y utilidad por mes")
    .setOption("legend", { position: "bottom" })
    .setOption("vAxis", { format: "short" })
    .setPosition(15, 6, 0, 0)
    .build();
  sheet.insertChart(monthlyChart);

  const categoryChart = sheet.newChart()
    .asColumnChart()
    .addRange(sheet.getRange("A25:D36"))
    .setOption("title", "Resultado por categoria")
    .setOption("legend", { position: "bottom" })
    .setOption("vAxis", { format: "short" })
    .setPosition(33, 6, 0, 0)
    .build();
  sheet.insertChart(categoryChart);
}

function title_(sheet, titleRange, title, subtitleRange, subtitle) {
  sheet.getRange(titleRange).merge().setValue(title)
    .setBackground(COLORS.primary)
    .setFontColor(COLORS.white)
    .setFontWeight("bold")
    .setFontSize(18)
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle");
  sheet.getRange(titleRange).setRowHeight(42);
  sheet.getRange(subtitleRange).merge().setValue(subtitle)
    .setBackground(COLORS.softTeal)
    .setFontColor(COLORS.primaryDark)
    .setFontSize(10)
    .setHorizontalAlignment("center");
}

function section_(sheet, rangeA1, text, color) {
  sheet.getRange(rangeA1).merge().setValue(text)
    .setBackground(color)
    .setFontColor(COLORS.ink)
    .setFontWeight("bold")
    .setBorder(true, true, true, true, false, false, COLORS.border, SpreadsheetApp.BorderStyle.SOLID);
}

function darkHeader_(range) {
  return range.setBackground(COLORS.primary)
    .setFontColor(COLORS.white)
    .setFontWeight("bold")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setWrap(true)
    .setBorder(true, true, true, true, true, true, COLORS.border, SpreadsheetApp.BorderStyle.SOLID);
}

function header_(range, color) {
  return range.setBackground(color)
    .setFontColor(COLORS.ink)
    .setFontWeight("bold")
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setWrap(true)
    .setBorder(true, true, true, true, true, true, COLORS.border, SpreadsheetApp.BorderStyle.SOLID);
}

function body_(range) {
  return range.setBackground(COLORS.white)
    .setFontColor(COLORS.ink)
    .setVerticalAlignment("middle")
    .setBorder(true, true, true, true, true, true, COLORS.border, SpreadsheetApp.BorderStyle.SOLID);
}

function setWidths_(sheet, widths) {
  widths.forEach((width, index) => sheet.setColumnWidth(index + 1, width));
}

function validation_(range, values) {
  const rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(values, true)
    .setAllowInvalid(false)
    .build();
  range.setDataValidation(rule);
}

function getWorkbook_() {
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) return active;
  const configured = PropertiesService.getScriptProperties().getProperty("TARGET_SPREADSHEET_ID") || TARGET_SPREADSHEET_ID;
  if (!configured) {
    throw new Error("No hay hoja activa ni TARGET_SPREADSHEET_ID configurado.");
  }
  return SpreadsheetApp.openById(configured);
}

function getSheet_(name) {
  const sheet = getWorkbook_().getSheetByName(name);
  if (!sheet) {
    throw new Error(`No existe la hoja: ${name}. Ejecuta setupSistemaContable primero.`);
  }
  return sheet;
}

function nextEmptyRow_(sheet, keyColumn) {
  const maxRows = sheet.getMaxRows();
  const values = sheet.getRange(START_ROW, keyColumn, maxRows - START_ROW + 1, 1).getValues();
  for (let index = 0; index < values.length; index += 1) {
    if (!values[index][0]) return START_ROW + index;
  }
  return sheet.getLastRow() + 1;
}

function countDataRows_(sheet) {
  const last = Math.max(sheet.getLastRow(), START_ROW);
  return sheet.getRange(START_ROW, 1, last - START_ROW + 1, 1)
    .getDisplayValues()
    .filter((row) => row[0])
    .length;
}

function readColumn_(sheet, startRow, column) {
  const last = Math.max(sheet.getLastRow(), startRow);
  return sheet.getRange(startRow, column, last - startRow + 1, 1)
    .getDisplayValues()
    .map((row) => String(row[0]).trim())
    .filter(Boolean);
}

function readNames_(sheetName) {
  const sheet = getSheet_(sheetName);
  const last = Math.max(sheet.getLastRow(), START_ROW);
  return sheet.getRange(START_ROW, 2, last - START_ROW + 1, 1)
    .getDisplayValues()
    .map((row) => String(row[0]).trim())
    .filter(Boolean);
}

function parseDate_(value) {
  if (!value) return null;
  if (Object.prototype.toString.call(value) === "[object Date]") return value;
  const parts = String(value).split("-");
  if (parts.length === 3) {
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function toNumber_(value) {
  if (typeof value === "number") return value;
  return Number(String(value || "0").replace(/[^\d.-]/g, "")) || 0;
}

function timezone_() {
  return Session.getScriptTimeZone() || "America/Bogota";
}
